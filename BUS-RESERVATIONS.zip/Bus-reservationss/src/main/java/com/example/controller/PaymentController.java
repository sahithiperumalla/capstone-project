package com.example.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/v1/customer/payments")
public class PaymentController {

    @PostMapping("/checkout")
    public ResponseEntity<?> checkout(@RequestBody Map<String, Object> paymentData) {
        try {
            System.out.println("Payment request: " + paymentData);

            // Simulate successful payment and return bookingId
            Long bookingId = 123L; 

            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "message", "Payment successful",
                    "bookingId", bookingId
            ));
        } catch (Exception e) {
            return ResponseEntity.status(500).body(Map.of(
                    "success", false,
                    "message", "Payment failed"
            ));
        }
    }
}
