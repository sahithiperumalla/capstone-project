package com.example.controller;

import com.example.model.Trip;
import com.example.service.TripService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/trips")
public class TripController {

    @Autowired
    private TripService tripService;

   
    @GetMapping("/search")
    public List<Trip> searchTrips(@RequestParam String source,
                                  @RequestParam String destination,
                                  @RequestParam String date) {
        return tripService.searchTrips(source, destination, date);
    }

    
    @GetMapping("/{id}")
    public Trip getTrip(@PathVariable Long id) {
        return tripService.getTripById(id);
    }

    
    @GetMapping("/{id}/seats")
    public List<Integer> getBookedSeats(@PathVariable Long id) {
        return tripService.getBookedSeats(id);
    }
}
