package com.example.controller;

import com.example.DTO.BookingResponseDTO;
import com.example.DTO.PassengerDTO;
import com.example.DTO.PaymentDTO;
import com.example.model.Booking;
import com.example.model.BookingSeat;
import com.example.model.Passenger;
import com.example.service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v1/bookings")
@CrossOrigin(origins = "http://localhost:3000")
public class BookingController {

    @Autowired
    private BookingService bookingService;

    // Create Booking
    @PostMapping
    public BookingResponseDTO bookTrip(@RequestBody Map<String, Object> body) {
        Long userId = Long.valueOf(body.get("userId").toString());
        Long tripId = Long.valueOf(body.get("tripId").toString());
        BigDecimal amount = new BigDecimal(body.get("amount").toString());

        List<Integer> seats = (List<Integer>) body.get("seats");
        List<Map<String, Object>> passengers = (List<Map<String, Object>>) body.get("passengers");

        Booking booking = bookingService.bookTrip(userId, tripId, seats, amount, passengers);
        return convertToDTO(booking);
    }

    // Get Booking
    @GetMapping("/{id}")
    public BookingResponseDTO getBooking(@PathVariable Long id) {
        Booking booking = bookingService.getBooking(id);
        return convertToDTO(booking);
    }

    // Cancel Booking
    @DeleteMapping("/{id}")
    public String cancelBooking(@PathVariable Long id) {
        bookingService.cancelBooking(id);
        return "Booking with ID " + id + " cancelled successfully.";
    }

    // Helper to map entity -> DTO
    private BookingResponseDTO convertToDTO(Booking booking) {
        BookingResponseDTO dto = new BookingResponseDTO();
        dto.setBookingId(booking.getId());
        dto.setBookingDate(booking.getBookingDate());
        dto.setTotalAmount(booking.getTotalAmount());

        // Trip info
        if (booking.getTrip() != null) {
            dto.setBusName(booking.getTrip().getBusName());
            dto.setSource(booking.getTrip().getSource());
            dto.setDestination(booking.getTrip().getDestination());
        }

        // Passengers with seat numbers
        List<PassengerDTO> passengerDTOs = booking.getPassengers().stream().map(p -> {
            PassengerDTO pd = new PassengerDTO();
            pd.setId(p.getId());
            pd.setName(p.getName());
            pd.setAge(p.getAge());
            pd.setSex(p.getSex());

            BookingSeat seat = p.getSeat();
            pd.setSeatNumber(seat != null ? seat.getSeatNumber() : null);

            return pd;
        }).collect(Collectors.toList());
        dto.setPassengers(passengerDTOs);

        // Payment
        if (booking.getPayment() != null) {
            PaymentDTO payDTO = new PaymentDTO();
            payDTO.setMode(booking.getPayment().getPaymentMethod());
            payDTO.setAmount(booking.getPayment().getAmount());
            dto.setPayment(payDTO);
        }

        return dto;
    }
}
