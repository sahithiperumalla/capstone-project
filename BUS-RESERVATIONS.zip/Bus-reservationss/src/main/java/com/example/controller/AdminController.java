package com.example.controller;

import com.example.model.Bus;
import com.example.model.Trip;
import com.example.model.Route;
import com.example.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/admin")
@PreAuthorize("hasRole('ADMIN')")
public class AdminController {

    @Autowired
    private AdminService adminService;

    
    @GetMapping("/buses")
    public List<Bus> getAllBuses() { 
        return adminService.getAllBuses(); 
    }

    @PostMapping("/buses")
    public Bus addBus(@RequestBody Bus bus) { 
        return adminService.addBus(bus); 
    }

    @PutMapping("/buses/{id}")
    public Bus updateBus(@PathVariable Long id, @RequestBody Bus bus) {
        return adminService.updateBus(id, bus);
    }

    @DeleteMapping("/buses/{id}")
    public void deleteBus(@PathVariable Long id) { 
        adminService.deleteBus(id); 
    }

   
    @GetMapping("/trips")
    public List<Trip> getAllTrips() { 
        return adminService.getAllTrips(); 
    }

    @PostMapping("/trips")
    public Trip addTrip(@RequestBody Trip trip) { 
        return adminService.addTrip(trip); 
    }

    @PutMapping("/trips/{id}")
    public Trip updateTrip(@PathVariable Long id, @RequestBody Trip trip) {
        return adminService.updateTrip(id, trip);
    }

    @DeleteMapping("/trips/{id}")
    public void deleteTrip(@PathVariable Long id) { 
        adminService.deleteTrip(id); 
    }

   
    @GetMapping("/routes")
    public List<Route> getAllRoutes() { 
        return adminService.getAllRoutes(); 
    }

    @PostMapping("/routes")
    public Route addRoute(@RequestBody Route route) { 
        return adminService.addRoute(route); 
    }

    @PutMapping("/routes/{id}")
    public Route updateRoute(@PathVariable Long id, @RequestBody Route route) {
        return adminService.updateRoute(id, route);
    }

    @DeleteMapping("/routes/{id}")
    public void deleteRoute(@PathVariable Long id) { 
        adminService.deleteRoute(id); 
    }
}
