package com.example.controller;

import com.example.model.User;
import com.example.security.JwtUtil;
import com.example.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/v1/auth")
public class AuthController {

    @Autowired
    private UserService userService;

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private PasswordEncoder passwordEncoder;

    
    @PostMapping("/register")
    public User register(@RequestBody User user) {
        // Default role is USER if not provided
        if (user.getRole() == null || user.getRole().equalsIgnoreCase("CUSTOMER")) {
            user.setRole("USER");
        }

        
        user.setPassword(passwordEncoder.encode(user.getPassword()));

       
        return userService.saveUser(user);
    }

    
    @PostMapping("/login")
    public Map<String, String> login(@RequestBody Map<String, String> body) {
        String email = body.get("email");
        String password = body.get("password");

        Optional<User> userOpt = userService.findByEmail(email);
        if (userOpt.isEmpty()) throw new RuntimeException("Invalid email or password");

        User user = userOpt.get();
        if (!passwordEncoder.matches(password, user.getPassword())) {
            throw new RuntimeException("Invalid email or password");
        }

        String token = jwtUtil.generateToken(email);

        // Map CUSTOMER → USER for frontend
        String role = (user.getRole() != null) ? user.getRole().toUpperCase() : "USER";
        if (role.equals("CUSTOMER")) role = "USER";

        Map<String, String> response = new HashMap<>();
        response.put("token", token);
        response.put("role", role);
        response.put("name", user.getName());
        response.put("email", user.getEmail());

        return response;
    }
}
