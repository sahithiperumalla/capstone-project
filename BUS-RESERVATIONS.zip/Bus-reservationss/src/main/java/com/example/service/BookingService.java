package com.example.service;

import com.example.model.*;
import com.example.repository.BookingRepository;
import com.example.repository.UserRepository;
import com.example.repository.TripRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class BookingService {

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private TripRepository tripRepository;

    /**
     * Book a trip with passengers, seats, and payment.
     */
    @Transactional
    public Booking bookTrip(Long userId, Long tripId, List<Integer> seatNumbers,
                            BigDecimal amount, List<Map<String, Object>> passengersData) {
        Booking booking = new Booking();

        // ===== Fetch managed User & Trip entities =====
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found with id: " + userId));
        Trip trip = tripRepository.findById(tripId)
                .orElseThrow(() -> new RuntimeException("Trip not found with id: " + tripId));

        booking.setUser(user);
        booking.setTrip(trip);
        booking.setTotalAmount(amount);
        booking.setBookingDate(Instant.now()); 

        // ===== Create Passengers =====
        List<Passenger> passengers = new ArrayList<>();
        if (passengersData != null) {
            for (Map<String, Object> p : passengersData) {
                Passenger passenger = new Passenger();
                passenger.setName(p.get("name").toString());
                passenger.setAge(Integer.parseInt(p.get("age").toString()));
                passenger.setSex(p.get("sex").toString());
                passenger.setBooking(booking); // link to booking
                passengers.add(passenger);
            }
        }
        booking.setPassengers(passengers);

        // ===== Create BookingSeats =====
        List<BookingSeat> bookingSeats = new ArrayList<>();
        if (seatNumbers != null) {
            for (int i = 0; i < seatNumbers.size(); i++) {
                BookingSeat seat = new BookingSeat();
                seat.setSeatNumber(seatNumbers.get(i));
                seat.setSeatType(SeatType.NORMAL);
                seat.setBooking(booking);

                // Link seat to passenger if available
                if (i < passengers.size()) {
                    seat.setPassenger(passengers.get(i));
                    passengers.get(i).setSeat(seat); // make sure Passenger has @OneToOne seat
                }
                bookingSeats.add(seat);
            }
        }
        booking.setSeats(bookingSeats);

        // ===== Create Payment =====
        Payment payment = new Payment();
        payment.setAmount(amount);
        payment.setPaymentMethod("UPI"); // default payment method
        payment.setPaymentDate(Instant.now());
        payment.setBooking(booking);
        booking.setPayment(payment);

        // ===== Save Booking =====
        return bookingRepository.save(booking); // cascade should handle passengers, seats, payment
    }

    /**
     * Get a booking by ID.
     */
    @Transactional(readOnly = true)
    public Booking getBooking(Long id) {
        return bookingRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Booking not found with id: " + id));
    }

    /**
     * Cancel a booking.
     */
    @Transactional
    public void cancelBooking(Long id) {
        if (!bookingRepository.existsById(id)) {
            throw new RuntimeException("Cannot cancel. Booking not found with id: " + id);
        }
        bookingRepository.deleteById(id);
    }
}
