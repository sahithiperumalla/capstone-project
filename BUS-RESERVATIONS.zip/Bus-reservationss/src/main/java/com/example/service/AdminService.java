package com.example.service;

import com.example.model.Bus;
import com.example.model.Trip;
import com.example.model.Route;
import com.example.repository.BusRepository;
import com.example.repository.TripRepository;
import com.example.repository.RouteRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AdminService {

    @Autowired
    private BusRepository busRepository;

    @Autowired
    private TripRepository tripRepository;

    @Autowired
    private RouteRepository routeRepository;

    // ===== BUS CRUD =====
    public Bus addBus(Bus bus) { return busRepository.save(bus); }
    public List<Bus> getAllBuses() { return busRepository.findAll(); }
    public Bus updateBus(Long id, Bus busDetails) {
        Bus bus = busRepository.findById(id).orElseThrow(() -> new RuntimeException("Bus not found"));
        bus.setBusNumber(busDetails.getBusNumber());
        bus.setType(busDetails.getType());
        bus.setTotalSeats(busDetails.getTotalSeats());
        return busRepository.save(bus);
    }
    public void deleteBus(Long id) { busRepository.deleteById(id); }

    // ===== TRIP CRUD =====
    public Trip addTrip(Trip trip) { return tripRepository.save(trip); }
    public List<Trip> getAllTrips() { return tripRepository.findAll(); }
    public Trip updateTrip(Long id, Trip tripDetails) {
        Trip trip = tripRepository.findById(id).orElseThrow(() -> new RuntimeException("Trip not found"));
        trip.setBusName(tripDetails.getBusName());
        trip.setSource(tripDetails.getSource());
        trip.setDestination(tripDetails.getDestination());
        trip.setDepartureTime(tripDetails.getDepartureTime());
        trip.setArrivalTime(tripDetails.getArrivalTime());
        trip.setPrice(tripDetails.getPrice());
        trip.setDate(tripDetails.getDate());
        return tripRepository.save(trip);
    }
    public void deleteTrip(Long id) { tripRepository.deleteById(id); }

    // ===== ROUTE CRUD =====
    public Route addRoute(Route route) { return routeRepository.save(route); }
    public List<Route> getAllRoutes() { return routeRepository.findAll(); }
    public Route updateRoute(Long id, Route routeDetails) {
        Route route = routeRepository.findById(id).orElseThrow(() -> new RuntimeException("Route not found"));
        route.setSource(routeDetails.getSource());
        route.setDestination(routeDetails.getDestination());
        route.setDistance(routeDetails.getDistance());
        route.setDuration(routeDetails.getDuration());
        return routeRepository.save(route);
    }
    public void deleteRoute(Long id) { routeRepository.deleteById(id); }
}
