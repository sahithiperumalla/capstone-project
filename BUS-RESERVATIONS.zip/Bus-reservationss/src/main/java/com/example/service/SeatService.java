package com.example.service;

import com.example.model.BookingSeat;
import com.example.model.SeatType;
import com.example.repository.BookingSeatRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class SeatService {

    private final BookingSeatRepository bookingSeatRepository;

    public SeatService(BookingSeatRepository bookingSeatRepository) {
        this.bookingSeatRepository = bookingSeatRepository;
    }

    // Custom POJO for seat info
    public static class SeatInfo {
        private int seatNumber;
        private SeatType seatType;
        private boolean booked;

        public SeatInfo(int seatNumber, SeatType seatType, boolean booked) {
            this.seatNumber = seatNumber;
            this.seatType = seatType;
            this.booked = booked;
        }

        public int getSeatNumber() { return seatNumber; }
        public SeatType getSeatType() { return seatType; }
        public boolean isBooked() { return booked; }
    }

    public List<SeatInfo> getSeatsForTrip(Long tripId) {
        List<BookingSeat> bookedSeats = bookingSeatRepository.findByBookingTripId(tripId);

        List<Integer> bookedSeatNumbers = bookedSeats.stream()
                .map(BookingSeat::getSeatNumber)
                .collect(Collectors.toList());

        List<SeatInfo> seats = new ArrayList<>();
        for (int i = 1; i <= 40; i++) {
            SeatType type;
            if (i == 1) type = SeatType.DRIVER;
            else if (i == 2) type = SeatType.CONDUCTOR;
            else type = SeatType.NORMAL;

            boolean isBooked = bookedSeatNumbers.contains(i);
            seats.add(new SeatInfo(i, type, isBooked));
        }

        return seats;
    }
}
