package com.example.service;

import com.example.model.BookingSeat;
import com.example.model.Trip;
import com.example.repository.BookingSeatRepository;
import com.example.repository.TripRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class TripService {

    @Autowired
    private TripRepository tripRepository;

    @Autowired
    private BookingSeatRepository bookingSeatRepository;

    // Search trips by source, destination, and date
    public List<Trip> searchTrips(String source, String destination, String dateStr) {
        LocalDate date = null;
        if (dateStr != null && !dateStr.isEmpty()) {
            date = LocalDate.parse(dateStr); // convert string to LocalDate
        }
        return tripRepository.searchTrips(source, destination, date);
    }

    // Get trip by ID
    public Trip getTripById(Long id) {
        return tripRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Trip not found"));
    }

    // Get booked seat numbers for a trip
    public List<Integer> getBookedSeats(Long tripId) {
        List<BookingSeat> bookedSeats = bookingSeatRepository.findByBookingTripId(tripId);
        return bookedSeats.stream()
                .map(BookingSeat::getSeatNumber)
                .collect(Collectors.toList());
    }
}
