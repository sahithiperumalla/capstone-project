package com.example.service;

import com.example.model.Bus;
import com.example.repository.BusRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BusService {

    @Autowired private final BusRepository busRepository;

    public BusService(BusRepository busRepository) {
        this.busRepository = busRepository;
    }

    //  Add new bus
    public Bus addBus(Bus bus) {
        return busRepository.save(bus);
    }

    //  Get all buses
    public List<Bus> getAllBuses() {
        return busRepository.findAll();
    }

    // Get bus by ID
    public Bus getBusById(Long id) {
        return busRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Bus not found with id: " + id));
    }

    //  Delete bus
    public void deleteBus(Long id) {
        busRepository.deleteById(id);
    }
}