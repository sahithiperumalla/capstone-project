package com.example.model;
public enum SeatLockStatus { HELD, BOOKED, EXPIRED }