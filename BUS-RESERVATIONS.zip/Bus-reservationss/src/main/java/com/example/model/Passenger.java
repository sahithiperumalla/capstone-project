package com.example.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;

@Entity
public class Passenger {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private Integer age;
    private String sex;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "booking_id")
    @JsonBackReference
    private Booking booking;

    @OneToOne(mappedBy = "passenger", fetch = FetchType.LAZY)
    private BookingSeat seat;

    
    public Long getId() { return id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public Integer getAge() { return age; }
    public void setAge(Integer age) { this.age = age; }

    public String getSex() { return sex; }
    public void setSex(String sex) { this.sex = sex; }

    public Booking getBooking() { return booking; }
    public void setBooking(Booking booking) {
        this.booking = booking;
        if (booking != null && !booking.getPassengers().contains(this)) {
            booking.getPassengers().add(this);
        }
    }

    public BookingSeat getSeat() { return seat; }
    public void setSeat(BookingSeat seat) { this.seat = seat; }
}
