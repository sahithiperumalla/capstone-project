package com.example.model;

import jakarta.persistence.*;

@Entity
@Table(name = "bus")
public class Bus {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String busNumber;

    @Column(nullable = false)
    private String type;

    @Column(nullable = false)
    private int totalSeats;

    
    public Bus() {}

  
    public Bus(Long id, String busNumber, String type, int totalSeats) {
        this.id = id;
        this.busNumber = busNumber;
        this.type = type;
        this.totalSeats = totalSeats;
    }

    // Getters and setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getBusNumber() { return busNumber; }
    public void setBusNumber(String busNumber) { this.busNumber = busNumber; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public int getTotalSeats() { return totalSeats; }
    public void setTotalSeats(int totalSeats) { this.totalSeats = totalSeats; }
}
