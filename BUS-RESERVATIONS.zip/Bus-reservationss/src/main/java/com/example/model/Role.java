package com.example.model;
public enum Role { ROLE_ADMIN, ROLE_CUSTOMER }