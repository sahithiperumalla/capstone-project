package com.example.model;

public enum SeatType {
    DRIVER,
    CONDUCTOR,
    NORMAL
}
