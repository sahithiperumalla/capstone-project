package com.example.model;
public enum BookingStatus { PENDING, CONFIRMED, CANCELLED }