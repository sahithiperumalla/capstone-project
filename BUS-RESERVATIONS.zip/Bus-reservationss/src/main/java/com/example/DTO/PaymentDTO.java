package com.example.DTO;

import java.math.BigDecimal;

public class PaymentDTO {
    private String mode;
    private BigDecimal amount;

    // Getters & Setters
    public String getMode() { return mode; }
    public void setMode(String mode) { this.mode = mode; }

    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }
}
