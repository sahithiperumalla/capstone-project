package com.example.repository;

import com.example.model.BookingSeat;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BookingSeatRepository extends JpaRepository<BookingSeat, Long> {

    // Fetch all BookingSeat records for a given trip ID
    List<BookingSeat> findByBookingTripId(Long tripId);
}
