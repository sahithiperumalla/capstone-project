package com.example.repository;

import com.example.model.Trip;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface TripRepository extends JpaRepository<Trip, Long> {

    // Search trips by source, destination, and optional date
    @Query("SELECT t FROM Trip t WHERE t.source = :source AND t.destination = :destination " +
            "AND (:date IS NULL OR t.date = :date)")
    List<Trip> searchTrips(
            @Param("source") String source,
            @Param("destination") String destination,
            @Param("date") LocalDate date
    );
}
